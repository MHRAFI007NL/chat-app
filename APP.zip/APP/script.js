const chatBox = document.getElementById('chatBox');
const chatInput = document.getElementById('chatInput');

function sendMessage() {
  const text = chatInput.value.trim();
  if (text === '') return;

  const message = document.createElement('div');
  message.className = 'message my-message';
  message.innerText = text;

  chatBox.appendChild(message);
  chatBox.scrollTop = chatBox.scrollHeight;
  chatInput.value = '';
}

chatInput.addEventListener('keydown', function (e) {
  if (e.key === 'Enter') {
    sendMessage();
  }
});

function inviteFriend() {
  const link = `${window.location.href}?invite=${Math.random().toString(36).substr(2, 8)}`;
  navigator.clipboard.writeText(link).then(() => {
    alert(`Invite link copied to clipboard:\n${link}`);
  });
}
